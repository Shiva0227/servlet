package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	public static Connection con;
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RegisterServlet() {
    	super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");//MIME type
		PrintWriter out=response.getWriter();
		String fname=request.getParameter("fn");
		String lname=request.getParameter("ln");
		String email=request.getParameter("em");
		String mobile=request.getParameter("mb");
		String address=request.getParameter("lc");
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			PreparedStatement ps=con.prepareStatement("insert into EmployeeiNFO(EMPFNAME,EMPLNAME,EMPEMAIL,EMPNUM,EMPADD) values(?,?,?,?,?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4, mobile);
			ps.setString(5, address);
			int i=ps.executeUpdate();
			if(i>0) {
				out.println("<h2>Welcome To Employee Registration</h2>");
				out.println("<h3>Mr."+fname+" "+lname+"you have successfully resgisterd</h3>");
				out.println("<h3>your Details: <h3>");
				out.println("<h4>First Name:<strong> "+fname+"</strong></h4>");
				out.println("<h4>Last Name:<strong> "+lname+"</strong></h4>");
				out.println("<h4>Email:<strong> "+email+"</strong></h4>");
				out.println("<h4>Mobile Number:<strong> "+mobile+"</strong></h4>");
				out.println("<h4>Address:<strong> "+address+"</strong></h4>");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		finally {
			try {
			con.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
			
		}
	

	}

