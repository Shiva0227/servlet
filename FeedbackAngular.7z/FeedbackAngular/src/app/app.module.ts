import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{Route,RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { FeedbackComponent } from './feedback/feedback.component';
import {FormsModule} from '@angular/forms';

const routes:Route[]=[
  {
    path:'feedbackform',
    component:FeedbackComponent
  }];




@NgModule({
  declarations: [
    AppComponent,
    FeedbackComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes),FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent,]
})
export class AppModule { }
