package com.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.capstore.dao.FeedbackRepository;
import com.capstore.model.FeedbackCommon;

public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepo;

	public Iterable<FeedbackCommon> getAllFeedbacks() {
		return feedbackRepo.findAll();
	}

	public void setStatus()
	{
		feedbackRepo.findAll().forEach(a->a.setStatus("Disapprove"));
	}

}
